from scripts.create_practiotioner_role import CreatePractitioner
from scripts.create_practitioner import CreatePerson

__all__ = ["CreatePerson", "CreatePractitioner"]
