import json

from scripts.extractors.active_extractor import ActiveExtractors
from scripts.extractors.address_extractor import AddressExtractors
from scripts.extractors.configs import BASE_TAGS, PERSON_DEFAULT_OUTPUT_FILE_LOCATION
from scripts.extractors.identifier_extractor import IdentifierExtractors
from scripts.extractors.language_extractor import LanguageExtractors
from scripts.extractors.name_extractor import NameExtractors
from scripts.extractors.organization_extractor import OrganizationExtractors
from scripts.extractors.qualification_extractor import QualificationExtractors
from scripts.extractors.telecom_extractors import TelecomExtractors
from scripts.extractors.update_info_extractor import UpdateInfoExtractors
from scripts.extractors.utils import (
    create_file,
    remove_base_data_tags,
    xml_to_json_converter,
)


class CreatePerson:
    def __init__(
        self, file_name, output_file_location=PERSON_DEFAULT_OUTPUT_FILE_LOCATION
    ):
        self.file_name = file_name
        self.out_file_loc_nam = output_file_location
        self.__json_objs = self.create_obj()
        self.iterate_over_the_obj()

    def create_obj(self):
        json_data = xml_to_json_converter(self.file_name)
        data = json.loads(json_data)
        data = remove_base_data_tags(data, BASE_TAGS)
        return data

    @staticmethod
    def create_file_name(*args):
        return f"{'_'.join(args)}.fhir.json"

    def iterate_over_the_obj(self):
        for _data in self.__json_objs:
            __fin_data = {
                "resourceType": "Practitioner",
                "meta": {"lastUpdated": UpdateInfoExtractors(_data).call_default},
                "identifier": IdentifierExtractors(_data).call_default,
                "name": NameExtractors(_data).call_default,
                "telecom": TelecomExtractors(_data).call_default,
                "gender": "",  # :TODO: yet to figure a way to do this as there is no field available in the xml file
                "birthDate": "",  # :TODO: yet to figure a way to do this as there is no field available in the xml file
                "address": AddressExtractors(_data).call_default,
                "photo": "",  # :TODO: yet to figure a way to do this as there is no field available in the xml file
                "active": ActiveExtractors(_data).call_default,
                "link": [{}],
                "language": LanguageExtractors(_data).call_default,
                "qualification": QualificationExtractors(_data).call_default,
            }

            self._final_file_name = self.create_file_name(
                self.file_name.split(".")[-2], __fin_data.get("identifier")[0]
            )
            create_file(f"{self.out_file_loc_nam}/{self._final_file_name}", __fin_data)


if __name__ == "__main__":
    CreatePerson("../sample/sample1/sample.xml")
