import json

from scripts.extractors.active_extractor import ActiveExtractors
from scripts.extractors.address_extractor import AddressExtractors
from scripts.extractors.configs import (
    BASE_TAGS,
    PRACTITIONER_DEFAULT_OUTPUT_FILE_LOCATION,
)
from scripts.extractors.identifier_extractor import IdentifierExtractors
from scripts.extractors.name_extractor import NameExtractors
from scripts.extractors.organization_extractor import OrganizationExtractors
from scripts.extractors.telecom_extractors import TelecomExtractors
from scripts.extractors.utils import (
    create_file,
    remove_base_data_tags,
    xml_to_json_converter,
)


class CreateOrganization:
    def __init__(
        self, file_name, output_file_location=PRACTITIONER_DEFAULT_OUTPUT_FILE_LOCATION
    ):
        self.file_name = file_name
        self.out_file_loc_nam = output_file_location
        self.__json_objs = self.create_obj()
        self.iterate_over_the_obj()

    def create_obj(self):
        json_data = xml_to_json_converter(self.file_name)
        data = json.loads(json_data)
        data = remove_base_data_tags(data, BASE_TAGS)
        return data

    @staticmethod
    def create_file_name(*args):
        return f"{'_'.join(args)}.fhir.json"

    def iterate_over_the_obj(self):
        for _data in self.__json_objs:
            __fin_data = {
                "resourceType": "Organization",
                "identifier": IdentifierExtractors(_data).call_default,
                "active": ActiveExtractors(_data).call_default,
                "type": [{"text": "prov"}],
                "name": OrganizationExtractors(_data).call_default,
                "alias": [OrganizationExtractors(_data).call_default],
                "address": AddressExtractors(_data).call_default,
                "telecom": TelecomExtractors(_data).call_default,
                "contact": [
                    {
                        "purpose": {"text": "ADMIN"},
                        "name": NameExtractors(_data).call_default,
                        "telecom": TelecomExtractors(_data).call_default,
                    }
                ],
            }

            self._final_file_name = self.create_file_name(
                self.file_name.split(".")[-2], __fin_data.get("identifier")[0]
            )
            create_file(f"{self.out_file_loc_nam}/{self._final_file_name}", __fin_data)


if __name__ == "__main__":
    CreateOrganization("../sample/sample.xm")
