import json

from scripts.extractors.active_extractor import ActiveExtractors
from scripts.extractors.address_extractor import AddressExtractors
from scripts.extractors.birthdate_extractor import BirthDateExtractors
from scripts.extractors.configs import (
    BASE_TAGS, BUNDLE_DEFAULT_OUTPUT_FILE_LOCATION,
    BASE_TAGS_PROVIDER, BASE_TAGS_ROSTER)
from scripts.extractors.days_of_week_extractor import DaysOfWeekExtractors
from scripts.extractors.gender_extractor import GenderExtractors
from scripts.extractors.healthcare_service_extractor import HealthcareServiceExtractors
from scripts.extractors.language_extractor import LanguageExtractors
from scripts.extractors.location_extractor import LocationExtractors
from scripts.extractors.name_extractor import NameExtractors
from scripts.extractors.npi_extractor import NPIsExtractors
from scripts.extractors.organization_extractor import OrganizationExtractors
from scripts.extractors.practitioner_role_extractor import PractitionerRoleExtractors
from scripts.extractors.qualification_extractor import QualificationExtractors
from scripts.extractors.speciality_extractor import SpecialityExtractors
from scripts.extractors.telecom_extractors import TelecomExtractors
from scripts.extractors.update_info_extractor import UpdateInfoExtractors
from scripts.extractors.utils import (
    create_file,
    remove_base_data_tags,
    xml_to_json_converter,
)


class CreateBundle:
    def __init__(
        self, data="empty", file_name="../inputs/sample.xml", output_file_location= BUNDLE_DEFAULT_OUTPUT_FILE_LOCATION
    ):
        self.file_name = file_name
        self.out_file_loc_nam = output_file_location
        self.data = data
        self.data = self.create_obj()
        # self.__json_objs = self.create_obj()
        # self.iterate_over_the_obj()

    def create_obj(self):
        if self.data == "empty":
            json_data = xml_to_json_converter(self.file_name)
            data = json.loads(json_data)
            data = remove_base_data_tags(data, BASE_TAGS)
            self.iterate_over_the_obj()
        else:
            data = self.data
        return data

    @staticmethod
    def create_file_name(*args):
        return f"{'_'.join(args)}.fhir.json"

    @property
    def call_default(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.business_id_extractor())
        return __final_identifier_data

    @property
    def call_default_roster(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.roster_id_extractor())
        return __final_identifier_data

    @property
    def call_default_provider(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.provider_id_extractor())
        return __final_identifier_data


    def business_id_extractor(self, path=None):
        try:
            if isinstance(self.data.get("updateInfo"), str):
                #print(self.data.get("updateInfo"))
                return [self.data.get("businessId"), self.data.get("updateInfo"), self.data.get("businessName")]
            else:
                #print(self.data.get("businessId"), self.data.get("updateInfo").get("attestationDate"))
                return [self.data.get("businessId"), self.data.get("updateInfo").get("attestationDate"), self.data.get("businessName")]
        except Exception as e:
            print(e)
            return ""

    def roster_id_extractor(self, path=None):
        try:
            if isinstance(self.data.get("providerId"), str):
                #print(self.data.get("businessId"))
                return [self.data.get("businessId"), self.data.get("providerId")]
            else:
                #print([self.data.get("businessId"), self.data.get("providerId")])
                return [self.data.get("businessId"), self.data.get("providerId")]
        except Exception as e:
            print(e)
            return ""

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data



    def provider_id_extractor(self, path=None):
        return [self.data.get("providerId"), self.data.get("updateInfo").get("attestationDate"), self.data]

    def iterate_over_the_obj(self):

        json_data = xml_to_json_converter("../inputs/sample.xml")
        data = json.loads(json_data)
        data = remove_base_data_tags(data, BASE_TAGS)
        data_provider = json.loads(json_data)
        data_provider = remove_base_data_tags(data_provider, BASE_TAGS_PROVIDER)
        data_roster = json.loads(json_data)
        data_roster = remove_base_data_tags(data_roster, BASE_TAGS_ROSTER)
        for _data_ in data:
            businessId = CreateBundle(_data_).call_default[0]
            attestationDate = CreateBundle(_data_).call_default[1]
            businessName = CreateBundle(_data_).call_default[2]
            #print(businessId, attestationDate)
            for rdata in data_roster:
                rbusinessId = CreateBundle(rdata).call_default_roster[0]
                rproviderId = CreateBundle(rdata).call_default_roster[1]
                if rbusinessId == businessId:
                    for pdata in data_provider:
                        pproviderId = CreateBundle(pdata).call_default_provider[0]
                        pattestationDate = CreateBundle(pdata).call_default_provider[1]
                        pprovider = CreateBundle(pdata).call_default_provider[2]
                        if pproviderId == rproviderId and attestationDate == pattestationDate:
                            #print(businessId, attestationDate, pprovider)
                            _data = pprovider
                            __fin_data = []
                            __fin_data.append({
                                "resourceType": "Bundle",
                                "type": "transaction",
                                "entry": [
                                    {
                                        "resource": {
                                            "resourceType": "Practitioner",
                                            "meta": {
                                                "source": "www.Availity.com",
                                                "lastUpdated": UpdateInfoExtractors(_data).call_default,
                                            },
                                            "identifier": [
                                                {
                                                    # "system": "http:availity/business/EIN/",
                                                    "value":businessId
                                                },
                                                {
                                                    # "system": "http:availity/provider/providerID/",
                                                    "value":pproviderId
                                                },
                                                {
                                                    "system": "http://hl7.org/fhir/sid/us-npi",
                                                    "value": ''.join(NPIsExtractors(_data).call_default),
                                                },
                                            ],
                                            "active": ActiveExtractors(_data).call_default,
                                            "name": NameExtractors(_data).call_default,
                                            "gender": GenderExtractors(_data).call_default,
                                            "birthDate": BirthDateExtractors(_data).call_default[0],
                                            "qualification": QualificationExtractors(_data).call_default,
                                            "communication": [
                                                {
                                                    "coding": LanguageExtractors(_data).call_default,
                                                    "text": "Language"
                                                }
                                            ],
                                        },
                                        "request": {"method": "POST", "url": "Practitioner"},
                                    },

                                    {
                                        "resource": {
                                            "resourceType": "Organization",
                                            "identifier": [
                                                {
                                                    # "system": "http:availity/business/EIN/",
                                                    "value": businessId
                                                },
                                                {
                                                    # "system": "http:availity/provider/providerID/",
                                                    "value": pproviderId
                                                },
                                                {
                                                    "system": "http://hl7.org/fhir/sid/us-npi",
                                                    "value": ''.join(NPIsExtractors(_data).call_default),
                                                },
                                            ],
                                            "active": ActiveExtractors(_data).call_default,
                                            "type": [{"text": "prov"}],
                                            "name": OrganizationExtractors(_data_).call_default,
                                            "address": AddressExtractors(_data).call_default,
                                            "telecom": TelecomExtractors(_data).call_default,
                                            "contact": [
                                                {
                                                    "purpose": {"text": "ADMIN"},
                                                    "name": NameExtractors(_data).call_default,
                                                    "telecom": TelecomExtractors(_data).call_default,
                                                    "address": AddressExtractors(_data).call_default
                                                }
                                            ],
                                        }

                                    },

                                    {
                                        "resource": {
                                            "resourceType": "HealthcareService",
                                            "identifier": [
                                                {
                                                    # "system": "http:availity/business/EIN/",
                                                    "value": businessId
                                                },
                                                {
                                                    "system": "http://hl7.org/fhir/sid/us-npi",
                                                    "value": ''.join(NPIsExtractors(_data).call_default),
                                                },
                                            ],
                                            "active": ActiveExtractors(_data).call_default,
                                            "providedby": OrganizationExtractors(_data_).call_default,
                                            "speciality": [
                                                {
                                                    "coding": [SpecialityExtractors(_data).call_default, ]
                                                }
                                            ],
                                            "telecom": TelecomExtractors(_data).call_default,
                                            "communication": [
                                                {
                                                    "coding": LanguageExtractors(_data).call_default,
                                                    "text": "Language"
                                                }
                                            ],
                                            "availableTime": DaysOfWeekExtractors(_data).call_default,
                                        }
                                    },
                                ],
                            }
                            )

                            __fin_data[0].get("entry").extend(PractitionerRoleExtractors(pdata,businessName).call_default)
                            __fin_data[0].get("entry").extend(LocationExtractors(pdata).call_default)

                            # self._final_file_name = self.create_file_name(
                            #     self.file_name.split(".")[-2], _data.get("businessId")
                            # )
                            # create_file(f"{self.out_file_loc_nam}/{self._final_file_name}", __fin_data)
                            out_file_loc_nam = "../outputs"

                            _final_file_name = str(businessId) + "_" + rproviderId + ".json"

                            create_file(f"{out_file_loc_nam}/{_final_file_name}", __fin_data)


if __name__ == "__main__":
    CreateBundle("empty", "../inputs/sample.xml")

