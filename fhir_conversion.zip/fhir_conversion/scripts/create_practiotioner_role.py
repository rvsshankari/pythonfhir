import json

from scripts.extractors.active_extractor import ActiveExtractors
from scripts.extractors.configs import (
    BASE_TAGS_PROVIDER,
    PRACTITIONER_DEFAULT_OUTPUT_FILE_LOCATION,
)
from scripts.extractors.days_of_week_extractor import DaysOfWeekExtractors
from scripts.extractors.healthcare_service_extractor import HealthcareServiceExtractors
from scripts.extractors.identifier_extractor import IdentifierExtractors
from scripts.extractors.language_extractor import LanguageExtractors
from scripts.extractors.location_extractor import LocationExtractors
from scripts.extractors.organization_extractor import OrganizationExtractors
from scripts.extractors.practitioner_role_extractor import PractitionerRoleExtractors
from scripts.extractors.speciality_extractor import SpecialityExtractors
from scripts.extractors.telecom_extractors import TelecomExtractors
from scripts.extractors.utils import (
    create_file,
    remove_base_data_tags,
    xml_to_json_converter,
)


class CreatePractitioner:
    def __init__(
        self, file_name, output_file_location=PRACTITIONER_DEFAULT_OUTPUT_FILE_LOCATION
    ):
        self.file_name = file_name
        self.out_file_loc_nam = output_file_location
        self.__json_objs = self.create_obj()
        self.iterate_over_the_obj()

    def create_obj(self):
        json_data = xml_to_json_converter(self.file_name)
        data = json.loads(json_data)
        data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
        return data

    @staticmethod
    def create_file_name(*args):
        return f"{'_'.join(args)}.fhir.json"

    def iterate_over_the_obj(self):
        for _data in self.__json_objs:
            __fin_data = {
                "resourceType": "PractitionerRole",
                "active": ActiveExtractors(_data).call_default,
                "period": {
                    "startDate": "",
                    "endDate": "",
                },  # :TODO: couldn't find the reference in the xml data need some more clarity
                "identifier": IdentifierExtractors(_data).call_default,
                "location": LocationExtractors(_data).call_default,
                "healthcareService": HealthcareServiceExtractors(_data).call_default,
                "telecom": TelecomExtractors(_data).call_default,
                "organization": OrganizationExtractors(_data).call_default,
                "practitioner": PractitionerRoleExtractors(_data).call_default,
                "specialty": SpecialityExtractors(_data).call_default,
                "availableTime": DaysOfWeekExtractors(_data).call_default,
                "language": LanguageExtractors(_data).call_default,
            }
            print(__fin_data)
            self._final_file_name = self.create_file_name(
                self.file_name.split(".")[-2], __fin_data.get("identifier")[0]
            )
            create_file(f"{self.out_file_loc_nam}/{self._final_file_name}", __fin_data)


if __name__ == "__main__":
    CreatePractitioner("../inputs/sample.xml")
