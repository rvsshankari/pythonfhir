from scripts.extractors.days_of_week_extractor import DaysOfWeekExtractors
from scripts.extractors.update_info_extractor import UpdateInfoExtractors
import logging


class LocationExtractors:

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_location_data = []
        __final_location_data.extend(self.location_extractors())
        return __final_location_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def location_extractors(self, path=None):
        if type(self.data) is not None:
            keys_to_search = self.data.keys()
        else:
            pass
        location_data = []
        try:
            if ("locations" in keys_to_search):
                if (type(self.data.get("locations")) is list or type(self.data.get("locations")) is dict):
                    if ("location" in self.data.get("locations")):
                        if not path:
                            path = "locations/location"
                        if isinstance(self.data.get("locations").get("location"), list):
                                for _i, _j in enumerate(self.extract_base(self.data, path)):
                                    if ("typeCode" in _j):
                                        location_data.append({
                                            "resources": {
                                                "resourceType": "Location",
                                                "meta": {
                                                    "source": "www.Availity.com",
                                                    "lastUpdated": UpdateInfoExtractors(self.data).call_default,
                                                },
                                                "address":
                                                    {
                                                        "identifier": _j["address"].get("id"),
                                                        "line": tuple(
                                                            [__i for __i in
                                                             [_j["address"].get("line1").upper(),
                                                              _j["address"].get("line2")]
                                                             if __i]),
                                                        "city": _j["address"].get("city"),
                                                        "state": _j["address"].get("stateCode"),
                                                        "postalCode": _j["address"].get("zip", {}).get("code"),
                                                        "use": _j["address"].get(
                                                            "use", "work"
                                                        ),
                                                        # added as part of the first feed back (the default value is 'work' )
                                                    },
                                                "telecom": [

                                                ],
                                                "hoursOfOperation": DaysOfWeekExtractors(self.data).call_default,
                                            }
                                        })
                                        if ("phone" in _j):
                                            ph = _j.get("phone").get("areaCode") + _j.get("phone").get("phoneNumber")
                                            loc = location_data[_i].get("resources").get("telecom")
                                            if type(loc) is list and len(loc) != 0:
                                                for i, j in enumerate(loc):
                                                    ph_loc = loc[i].get("value")
                                                if (ph != ph_loc):
                                                    location_data[_i].get("resources").get("telecom").extend(
                                                        [{
                                                            "system": "phone",
                                                            "value": ph,
                                                            "use": "work"
                                                        }])
                                            else:
                                                location_data[_i].get("resources").get("telecom").extend(
                                                    [{
                                                        "system": "phone",
                                                        "value": ph,
                                                        "use": "work"
                                                    }])
                                        if ("fax" in _j):
                                            location_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "fax",
                                                    "value": _j.get("fax").get("areaCode") + _j.get("fax").get("phoneNumber"),
                                                    "use": "work"
                                                }])
                                        if ("email" in _j):
                                            location_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "email",
                                                    "value": _j.get("email").lower(),
                                                    "use": "work"
                                                }])
                                        if ("alternatePhone" in _j):
                                            if ("phone" in _j):
                                                ap = _j.get("alternatePhone").get("phoneNumber")
                                                p = _j.get("phone").get("phoneNumber")
                                                if (ap!=p):
                                                    location_data[_i].get("resources").get("telecom").extend(
                                                        [{
                                                            "system": "alternatePhone",
                                                            "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                                "alternatePhone").get("phoneNumber"),
                                                            "use": "work"
                                                        }])
                                                else:
                                                    pass
                                            else:
                                                location_data[_i].get("resources").get("telecom").extend(
                                                    [{
                                                        "system": "alternatePhone",
                                                        "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                            "alternatePhone").get("phoneNumber"),
                                                        "use": "work"
                                                    }])
                                    else:
                                        return ""
                        elif isinstance(self.data.get("locations").get("location"), dict):
                                x = []
                                x.append(self.data.get("locations").get("location"))
                                for _i, _j in enumerate(x):
                                    if ("typeCode" in _j):
                                        location_data.append({
                                            "resources": {
                                                "resourceType": "Location",
                                                "meta": {
                                                    "source": "www.Availity.com",
                                                    "lastUpdated": UpdateInfoExtractors(self.data).call_default,
                                                },
                                                "address":
                                                    {
                                                        "identifier": _j["address"].get("id"),
                                                        "line": tuple(
                                                            [__i for __i in
                                                             [_j["address"].get("line1").upper(),
                                                              _j["address"].get("line2")]
                                                             if __i]),
                                                        "city": _j["address"].get("city"),
                                                        "state": _j["address"].get("stateCode"),
                                                        "postalCode": _j["address"].get("zip", {}).get("code"),
                                                        "use": _j["address"].get(
                                                            "use", "work"
                                                        ),
                                                        # added as part of the first feed back (the default value is 'work' )
                                                    },
                                                "telecom": [

                                                ],
                                                "hoursOfOperation": DaysOfWeekExtractors(self.data).call_default,
                                            }
                                        })
                                        if ("phone" in _j):
                                            ph = _j.get("phone").get("areaCode") + _j.get("phone").get("phoneNumber")
                                            loc = location_data[_i].get("resources").get("telecom")
                                            if type(loc) is list and len(loc) != 0:
                                                for i, j in enumerate(loc):
                                                    ph_loc = loc[i].get("value")
                                                    if (ph != ph_loc):
                                                        location_data[_i].get("resources").get("telecom").extend(
                                                            [{
                                                                "system": "phone",
                                                                "value": ph,
                                                                "use": "work"
                                                            }])
                                            else:
                                                location_data[_i].get("resources").get("telecom").extend(
                                                    [{
                                                        "system": "phone",
                                                        "value": ph,
                                                        "use": "work"
                                                    }])
                                        if ("fax" in _j):
                                            location_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "fax",
                                                    "value": _j.get("fax").get("areaCode") + _j.get("fax").get("phoneNumber"),
                                                    "use": "work"
                                                }])
                                        if ("email" in _j):
                                            location_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "email",
                                                    "value": _j.get("email").lower(),
                                                    "use": "work"
                                                }])
                                        if ("alternatePhone" in _j):
                                            if ("phone" in _j):
                                                ap = _j.get("alternatePhone").get("phoneNumber")
                                                p = _j.get("phone").get("phoneNumber")
                                                if (ap!=p):
                                                    location_data[_i].get("resources").get("telecom").extend(
                                                        [{
                                                            "system": "alternatePhone",
                                                            "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                                "alternatePhone").get("phoneNumber"),
                                                            "use": "work"
                                                        }])
                                                else:
                                                    pass
                                            else:
                                                location_data[_i].get("resources").get("telecom").extend(
                                                    [{
                                                        "system": "alternatePhone",
                                                        "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                            "alternatePhone").get("phoneNumber"),
                                                        "use": "work"
                                                    }])
                                    else:
                                        return ""
                        else:
                            pass
                        # print(location_data)
                        return (location_data)
                    else:
                        return ""
            else:
                return ""
        except Exception as e:
            # logging.exception("message")
            # print(e)
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    test = []
    for _data in data:
        LocationExtractors(_data).call_default
        # print(type((LocationExtractors(_data).call_default)))
