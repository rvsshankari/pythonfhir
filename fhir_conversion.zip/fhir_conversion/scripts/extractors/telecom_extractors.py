class TelecomExtractors:
    """
    Extracting all the telecom related tags
    :ref:
        locations/location/

    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        """
        Finally we need to merge all the extracted data into a single list(dict)
        So just using the crude method to club all those
        :return:
            list(dict) ---> [{}]
        """

        __final_telecom = []
        __final_telecom.extend(self.fax_extractors())
        __final_telecom.extend(self.email_extractors())
        __final_telecom.extend(self.phone_extractor())
        __final_telecom.extend(self.alternate_phone_extractor())
        # print(type(__final_telecom))
        return __final_telecom

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def fax_extractors(self, path=None):
        """
        Extracting the fax number
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "locations/location"

        fax_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("locations" in keys_to_search):
                if isinstance(self.data.get("locations").get("location"), list):
                    for i,j in enumerate(self.extract_base(self.data, path)):
                        if ("fax" in j):
                            fax_data.append(
                                {
                                 "system": "fax",
                                 "value": j.get("fax").get("areaCode") + j.get("fax").get("phoneNumber"),
                                 "use": "work"
                                }
                            )
                elif isinstance(self.data.get("locations").get("location"), dict):
                    x = []
                    x.append(self.data.get("locations").get("location"))
                    for i,j in enumerate(x):
                        if ("fax" in j):
                            fax_data.append(
                                {
                                 "system": "fax",
                                 "value": j.get("fax").get("areaCode") + j.get("fax").get("phoneNumber"),
                                 "use": "work"
                                }
                            )
            unique_fax = {each['value']: each for each in fax_data}.values()
            return unique_fax
        except:
            return ""

    def email_extractors(self, path=None):
        """
        Extracting the email address and formating
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "locations/location"

        email_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("locations" in keys_to_search):
                if isinstance(self.data.get("locations").get("location"), list):
                    for i,j in enumerate(self.extract_base(self.data, path)):
                        if ("email" in j):
                            email_data.append(
                                {
                                    "system": "email",
                                    "value": j.get("email").lower(),
                                    "use": "work"
                                })
                elif isinstance(self.data.get("locations").get("location"), dict):
                    x = []
                    x.append(self.data.get("locations").get("location"))
                    for i,j in enumerate(x):
                        if ("email" in j):
                            email_data.append(
                                {
                                    "system": "email",
                                    "value": j.get("email").lower(),
                                    "use": "work"
                                })
            unique_email = {each['value']: each for each in email_data}.values()
            return unique_email
        except:
            return ""

    def phone_extractor(self, path=None):
        """
        Extracting the phone number
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "locations/location"

        phone_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("locations" in keys_to_search):
                if isinstance(self.data.get("locations").get("location"), list):
                    for i,j in enumerate(self.extract_base(self.data, path)):
                        if ("phone" in j):
                            phone_data.append(
                            {
                                 "system": "phone",
                                 "value": j.get("phone").get("areaCode") + j.get("phone").get("phoneNumber"),
                                  "use": "work"
                            }
                            )
                elif isinstance(self.data.get("locations").get("location"), dict):
                    x = []
                    x.append(self.data.get("locations").get("location"))
                    for i,j in enumerate(x):
                        if ("phone" in j):
                            phone_data.append(
                            {
                                 "system": "phone",
                                 "value": j.get("phone").get("areaCode") + j.get("phone").get("phoneNumber"),
                                  "use": "work"
                            }
                            )
            unique_phone = {each['value']: each for each in phone_data}.values()
            return unique_phone
        except:
            return ""

    def alternate_phone_extractor(self, path=None):
        """
        Extracting the alternate phone number
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "locations/location"

        alt_ph_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("locations" in keys_to_search):
                if isinstance(self.data.get("locations").get("location"), list):
                    for i,j in enumerate(self.extract_base(self.data, path)):
                        if ("alternatePhone" in j):
                            alt_ph_data.append(
                                {
                                    "system": "alternate phone",
                                    "value": j.get("alternatePhone").get("areaCode") + j.get("alternatePhone").get("phoneNumber"),
                                    "use": "work"
                                }
                            )
                elif isinstance(self.data.get("locations").get("location"), dict):
                    x = []
                    x.append(self.data.get("locations").get("location"))
                    for i,j in enumerate(x):
                        if ("alternatePhone" in j):
                            alt_ph_data.append(
                                {
                                    "system": "alternate phone",
                                    "value": j.get("alternatePhone").get("areaCode") + j.get("alternatePhone").get("phoneNumber"),
                                    "use": "work"
                                }
                            )
            unique_alt_ph = {each['value']: each for each in alt_ph_data}.values()
            return unique_alt_ph

        except:
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        (TelecomExtractors(_data).call_default)
