class AddressSeparator:
    """
    The uniques id that needs to identify the individual user
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        businessId
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.address_separator())
        return __final_identifier_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data


    def address_separator(self, path=None):
        """
        getting the businessId as adding it as identifier in the Practitioner file
        :param path:
            keeping this for future as this might be need go through some path when
            we are getting the businessId
            So just keeping it here
        :return:
            list(str) ---> ['']
        """
        i = self.data
        x=[]
        try:
            if i.get("locations"):
                for j in i.get("locations"):
                    print(j["location"].get("typeCode"))
                #print(i)
                #x.append({i.get("locations").get("location")})
                #print(type(x))
            else:
                print("No locations")
            return i
        except Exception as e:
            print (e)
            return ""



if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        #print(_data)
        #print(AddressSeparator(_data).call_default[0])
        AddressSeparator(_data).call_default
