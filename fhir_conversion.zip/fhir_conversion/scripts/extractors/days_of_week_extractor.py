class DaysOfWeekExtractors:
    """
    We need to extract the the date time and weeks the practitioner works
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        locations/location/4/specialties/taxonomy
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.merge_and_create_final_data(
            self.days_of_week_extractors(),
            self.extract_start_time(),
            self.extract_end_time(),
        )

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def days_of_week_extractors(self, path=None):
        """
        We are extracting the weeks in which the practitioner works
        there is a possibly that the opening the hours might return None so added a default {}
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            list(str) ---> ['']
        """

        if not path:
            path = "locations/location"
        try:
            for _i in self.extract_base(self.data, path):
                _temp_list = []
                try:
                    # print(_i)
                    if ("hours" in _i):
                        for _j in _i.get("hours", {}).get("openingHour", {}):
                            # print(_j)
                            if("day" in _j):
                                # print(_j.get("day"))
                                _temp_list.append(_j.get("day"))
                            else:
                                return ""
                    else:
                        return ""
                    return _temp_list
                except Exception:
                    return _temp_list
        except:
            return ""

    def extract_start_time(self, path=None):
        """
        We are extracting the starting time of in which the practitioner works
        there is a possibly that the opening the hours might return None so added a default {}
        Also formatting with zfill to make it consistent with two values
        Means if the time is 1 it return 01
              if the time is 12 it return 12
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            list(str) ---> ['']
        """

        if not path:
            path = "locations/location"
        try:
            for _i in self.extract_base(self.data, path):
                _temp_list = []
                try:
                    if ("hours" in _i):
                        for _j in _i.get("hours", {}).get("openingHour", {}):
                            _temp_list.append(
                                f"{_j.get('startHour').zfill(2)}:{_j.get('startHour').zfill(2)}:00"
                            )
                    else:
                        return ""

                    return _temp_list
                except Exception:
                    return _temp_list
        except:
            return ""

    def extract_end_time(self, path=None):
        """
        We are extracting the end time of in which the practitioner exits
        there is a possibly that the opening the hours might return None so added a default {}
        Also formatting with zfill to make it consistent with two values
        Means if the time is 1 it return 01
              if the time is 12 it return 12
        :param path:
            the path at which we can find the tags to extrat data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            list(str) ---> ['']
        """

        if not path:
            path = "locations/location"
        try:
            for _i in self.extract_base(self.data, path):
                _temp_list = []
                try:
                    if ("hours" in _i):
                        for _j in _i.get("hours", {}).get("openingHour", {}):
                            _temp_list.append(
                                f"{_j.get('endHour').zfill(2)}:{_j.get('endMinute').zfill(2)}:00"
                            )
                    else:
                        return ""

                    return _temp_list
                except Exception:
                    return _temp_list
        except:
            return ""

    @staticmethod
    def merge_and_create_final_data(a, b, c):
        """
        As you can see very poor choice (or wise) on the args
        this we are doing the practitioner may not work on same time everyday so we need to create two spec
        list which contains the first week timing and week days and second the same with the rest of the
        Week days with start time and end time
        :param a:
            list of weeks
        :param b:
            list of start TIME
        :param c:
            list of end TIME
        :return:
            returns a list of dicts contains the two sets of different start and end datetime with week days
        """
        temp_list = []
        try:
            days_of_week = {
                "daysOfWeek": [],
                "availableStartTime": "",
                "availableEndTime": "",
            }

            days_of_week_1 = {
                "daysOfWeek": [],
                "availableStartTime": "",
                "availableEndTime": "",
            }

            for i, j, k in zip(a, b, c):
                if not days_of_week.get("availableStartTime") and not days_of_week.get(
                    "availableEndTime"
                ):
                    days_of_week["availableStartTime"] = j
                    days_of_week["availableEndTime"] = k
                    days_of_week["daysOfWeek"].append(i)

                elif (
                    days_of_week.get("availableStartTime") == j
                    and days_of_week.get("availableEndTime") == k
                ):
                    days_of_week["daysOfWeek"].append(i)
                else:
                    days_of_week_1["availableStartTime"] = j
                    days_of_week_1["availableEndTime"] = k
                    days_of_week_1["daysOfWeek"].append(i)

            temp_list.append(days_of_week)
            if days_of_week_1["availableStartTime"] and days_of_week_1["availableEndTime"]:
                temp_list.append(days_of_week_1)
            return temp_list
        except:
            return ""



if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    for _data in data:
        print(DaysOfWeekExtractors(_data).days_of_week_extractors())
        print(DaysOfWeekExtractors(_data).extract_start_time())
        print(DaysOfWeekExtractors(_data).extract_end_time())
        print(DaysOfWeekExtractors(_data).call_default)
