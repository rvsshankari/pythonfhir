class provider_id_extractor:
    def __init__(self, rdata):
        self.data = rdata
    @property
    def call_default(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.business_id_extractor())
        return __final_identifier_data
    @property
    def call_default_roster(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.roster_id_extractor())
        return __final_identifier_data
    @property
    def call_default_provider(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.provider_id_extractor())
        return __final_identifier_data

    def business_id_extractor(self, path=None):
        return [self.data.get("businessId"), self.data.get("updateInfo").get("attestationDate")]

    def roster_id_extractor(self, path=None):
        return [self.data.get("businessId"), self.data.get("providerId")]

    def provider_id_extractor(self, path=None):
        return [self.data.get("providerId"), self.data.get("updateInfo").get("attestationDate"), self.data]

if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS,BASE_TAGS_PROVIDER,BASE_TAGS_ROSTER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags
    # from scripts.extractors.Attestation_date_extractor import attestation_date_extractors

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    data_provider = json.loads(json_data)
    data_provider = remove_base_data_tags(data_provider, BASE_TAGS_PROVIDER)
    data_roster = json.loads(json_data)
    data_roster = remove_base_data_tags(data_roster, BASE_TAGS_ROSTER)


    for _data in data:
        businessId = provider_id_extractor(_data).call_default[0]
        attestationDate = provider_id_extractor(_data).call_default[1]
        # print(businessId,attestationDate)
        for rdata in data_roster:
            rbusinessId = provider_id_extractor(rdata).call_default_roster[0]
            rproviderId = provider_id_extractor(rdata).call_default_roster[1]
            if rbusinessId == businessId:
                # print(rbusinessId,rproviderId)
                for pdata in data_provider:
                    pproviderId = provider_id_extractor(pdata).call_default_provider[0]
                    pattestationDate = provider_id_extractor(pdata).call_default_provider[1]
                    pprovider = provider_id_extractor(pdata).call_default_provider[2]
                    if pproviderId == rproviderId and attestationDate == pattestationDate:
                        # print(pproviderId,pattestationDate)
                        # print(pprovider)
                        print(businessId,attestationDate,pprovider)