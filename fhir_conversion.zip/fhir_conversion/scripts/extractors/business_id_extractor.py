class BusinessIdExtractors:
    """
    The uniques id that needs to identify the individual user
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        businessId
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.attestation_date_extractors())
        return __final_identifier_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data


    def attestation_date_extractors(self, path=None):
        """
        getting the businessId as adding it as identifier in the Practitioner file
        :param path:
            keeping this for future as this might be need go through some path when
            we are getting the businessId
            So just keeping it here
        :return:
            list(str) ---> ['']
        """
        return [self.data.get("businessId"), self.data.get("updateInfo").get("attestationDate")]


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    print(len(data))
    # for _data in data:
    #     #print(_data)
    #     print(BusinessIdExtractors(_data).call_default[0],BusinessIdExtractors(_data).call_default[1])
