class OrganizationExtractors:
    """
    Name of the organization
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        businessName
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.organization_extractors()

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def organization_extractors(self, path=None):
        """
        just directly taking the org name
        :param path:
            keeping this for future as this might be need go through some path when
            we are getting the businessId
            So just keeping it here
        :return:
            str ---> ''
        """
        return self.data.get("businessName")


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    for _data in data:
        print(OrganizationExtractors(_data).call_default)
