class UpdateInfoExtractors:
    """
    Extracting the person or the practitioner is active or not from the provided data
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        updateInfo
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.update_info_extractors()

    def update_info_extractors(self, path=None):
        """
        just assuming the tag may or may not present so just making True as the default value and returning the value
        if that tar present it should be in the hierarchy else it will be return the default value which is True
        :param path:
            optional path to remove | added this for future implimentation if needed
        :return:
            the standard datetime format we want to return if not we are returning into all zero format
        """

        _up_data = self.data.get("updateInfo")
        if _up_data:
            return _up_data.get("lastUpdateDate")
        return "0000-00-00T00:00:00.000Z"


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../sample/sample1/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    for _data in data:
        print(UpdateInfoExtractors(_data).call_default)
