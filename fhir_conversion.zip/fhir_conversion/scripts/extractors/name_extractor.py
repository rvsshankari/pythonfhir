class NameExtractors:
    """
    Extracting the person name
    :ref:
        https://www.hl7.org/fhir/person.html
        locations/location/4/locationName
    """

    def __init__(self, pdata):
        self.data = pdata

    @property
    def call_default(self):
        return self.name_extractors()

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def name_extractors(self, path=None):
        """
        getting the first name and last name and appending those into a single list and passing on
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(str, str) ---> ['', '']
        """

        if not path:
            path = "updateInfo/attestator"

        # name_data = []
        # print(self.data)
        # _i = self.extract_base(self.data, path)
        # print(_i)
        #
        # name_data.append({"family": _i.get("lastName"),
        #                   "given": [_i.get("firstName"), _i.get("middleName")],
        #                   "prefix": [_i.get("prefix")],
        #                   "suffix": [_i.get("suffix")]
        #                   })
        # #print(name_data)
        # return name_data

        try:
            name_data = []
            pName = self.data.get("providerName")
            # print(pName)

            if pName.get("lastName"):
                name_data.append({"family": pName.get("lastName")})
            if (pName.get("firstName")) and (pName.get("middleName")):
                name_data.append({"given": [pName.get("firstName"), pName.get("middleName")]})
            elif pName.get("firstName"):
                name_data.append({"given": [pName.get("firstName")]})
            if pName.get("prefix"):
                name_data.append({"prefix": [pName.get("prefix")]})
            if pName.get("suffix"):
                name_data.append({"suffix": [pName.get("suffix")]})
            #print(name_data)
            #print(type(name_data))
            #dic_out = {x: y for x, y in name_data.items() if y != "empty"}
            #print(dic_out)
            return name_data

        except:
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS,BASE_TAGS_PROVIDER,BASE_TAGS_ROSTER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags
    # from scripts.extractors.provider_id_extractor import business_id_extractor,roster_id_extractor,provider_id_extractor

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        #print(data)
        #print(NameExtractors(_data).call_default)
        NameExtractors(_data).call_default