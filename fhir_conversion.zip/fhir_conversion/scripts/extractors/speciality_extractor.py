class SpecialityExtractors:
    """
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        locations/location/4/specialties/taxonomy
    :ex:
        [
            {
            "system": "http://snomed.info/sct",
            "code": "408443003",
            "display": "General medical practice"
            },
            "system": "http://snomed.info/sct",
            "code": "408443002",
            "display": "Surgeon"
            }
        ]
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_speciality_data = []
        __final_speciality_data.extend(self.speciality_extractors())
        return __final_speciality_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def speciality_extractors(self, path=None):
        """
        The special services offered should be and will be extracted here
        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "specialties/taxonomy"

        speciality_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("specialties" in self.data.keys()):
                if isinstance(self.data.get("specialties").get("taxonomy"), list):
                    for _i,_j in enumerate(self.extract_base(self.data, path)):
                        # if type(self.data) is not None:
                            speciality_data.append(
                                {
                                    #"system": "",  # keeping this empty until we figure how to take this from the provided data
                                    "code": _j.get("code"),
                                    "display": _j.get("classification"),
                                    "text": ''.join(_j.get("specialization"))
                                }
                            )
                elif isinstance(self.data.get("specialties").get("taxonomy"), dict):
                    x = []
                    x.append(self.data.get("specialties").get("taxonomy"))
                    for _i,_j in enumerate(x):
                        speciality_data.append(
                            {
                                # "system": "",  # keeping this empty until we figure how to take this from the provided data
                                "code": _j.get("code"),
                                "display": _j.get("classification"),
                                "text": ''.join(_j.get("specialization"))
                            }
                        )
                # print(speciality_data)
            return speciality_data
        except:
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        # print(_data)
        SpecialityExtractors(_data).call_default
        #print(SpecialityExtractors(_data).call_default)
