class LanguageExtractors:
    """
    Extracting the person or the practitioner Language or not from the provided data
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        locations/location/languageCodes
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.language_extractors()

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data


    def call_mapper_code(self, __lag__c):
        if __lag__c == "ENG":
            lang = "English"
        elif __lag__c == "SPA":
            lang = "Spanish"
        elif __lag__c == "POR":
            lang = "Portuguese"
        elif __lag__c == "RUS":
            lang = "Russian"
        elif __lag__c == "HIN":
            lang = "Hindi"
        elif __lag__c == "GUJ":
            lang = "Gujrati"
        elif __lag__c == "URD":
            lang = "Urdu"
        elif __lag__c == "PHI":
            lang = "Filipino"
        elif __lag__c == "VIE":
            lang = "Vietnamese"
        elif __lag__c == "PAN":
            lang = "Punjabi"
        elif __lag__c == "TGL":
            lang = "Tagalog"
        elif __lag__c == "KOR":
            lang = "Korean"
        elif __lag__c == "HEB":
            lang = "Hebrew"
        elif __lag__c == "FRA":
            lang = "French"
        elif __lag__c == "NEP":
            lang = "Nepali"
        elif __lag__c == "CAU":
            lang = "Caucasian"
        else:
            lang = ""
        return lang


    def language_extractors(self, path=None):
        """
        just assuming the tag may or may not present so just making True as the default value and returning the value
        if that tar present it should be in the hierarchy else it will be return the default value which is True
        :param path:
            optional path to remove | added this for future implimentation if needed
        :return:
            mostly will be a language code if present most of the time
            else will return an empty string
        """

        if not path:
            path = "languageCodes/"

        language_data = []
        try:
            __lag__c = self.data.get("languageCodes").get("languageCode")
            if isinstance(__lag__c, str):
                language_data.append(
                    {
                        "code": self.data.get("languageCodes").get("languageCode"),
                        "display": self.call_mapper_code(self.data.get("languageCodes").get("languageCode"))
                    }
                )
            else:
                for i in self.data.get("languageCodes").get("languageCode"):
                    language_data.append(
                        {
                            "code": i,
                            "display": self.call_mapper_code(i)
                        }
                    )

            return language_data
        except:
            return ""

if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)

    for _data in data:
        print(_data.get("providerId"))
        print(LanguageExtractors(_data).call_default)

