class ActiveExtractors:
    """
    Extracting the person or the practitioner is active or not from the provided data
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        active

    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.active_extractors()

    def active_extractors(self, path=None):
        """
        just assuming the tag may or may not present so just making True as the default value and returning the value
        if that tar present it should be in the hierarchy else it will be return the default value which is True
        :param path:
            optional path to remove | added this for future implimentation if needed
        :return:
            bool value
        """

        return self.data.get("active", True)


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../sample/sample1/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    for _data in data:
        print(ActiveExtractors(_data).call_default)
