class HealthcareServiceExtractors:
    """
    We need to extract the services offered by the practitioner
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        locations/location/4/specialties/taxonomy
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_healthcare_service_data = []
        __final_healthcare_service_data.extend(self.healthcare_service_extractors())
        return __final_healthcare_service_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def healthcare_service_extractors(self, path=None):
        """
        Just as a added precautionary we are adding the exception
        To remove the duplicated we are appending the values into a dictionary before formatting.(cleaver)

        :param path:
            the path at which we can find the tags to extract data
            these are base tags we will remove and the rest we process to extract the data
        :return:
            structured to match the address field in person file
            list(dict()) ---> [{}]
        """

        if not path:
            path = "specialties/taxonomy"

        health_service_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("specialties" in keys_to_search):
                if isinstance(self.data.get("specialties").get("taxonomy"), list):
                    __temp_dict = {}
                    for _i in self.extract_base(self.data, path):
                        try:
                            __temp_dict.update({_i["code"]: _i["classification"]})
                        except TypeError:
                            continue

                    for _idx, cde in enumerate(__temp_dict):
                        health_service_data.append(
                            {
                                "id": cde,
                                "reference": "HealthcareService" + f"/{_idx}",
                                "display": __temp_dict.get(cde),
                            }
                        )
                elif isinstance(self.data.get("specialties").get("taxonomy"), dict):
                    x = []
                    x.append(self.data.get("specialties").get("taxonomy"))
                    __temp_dict = {}
                    for _i in (x):
                        try:
                            __temp_dict.update({_i["code"]: _i["classification"]})
                        except TypeError:
                            continue

                        for _idx, cde in enumerate(__temp_dict):
                            health_service_data.append(
                                {
                                    "id": cde,
                                    "reference": "HealthcareService" + f"/{_idx}",
                                    "display": __temp_dict.get(cde),
                                }
                            )
            return health_service_data
        except:
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        print(HealthcareServiceExtractors(_data).call_default)
