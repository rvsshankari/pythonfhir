class AddressExtractors:
    """
    Extracting the address to attach into the person fhir json file
    :ref:
        https://www.hl7.org/fhir/person.html
        locations/location/4/locationName

    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        __final_address_data = []
        __final_address_data.extend(self.address_extractors())
        return __final_address_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data

    def address_extractors(self, path=None):

        if not path:
            path = "locations/location"

        address_data = []
        try:
            if type(self.data) is not None:
                keys_to_search = self.data.keys()
            if ("locations" in keys_to_search):
                if isinstance(self.data.get("locations").get("location"), list):
                    for _i in self.extract_base(self.data, path):
                        l = _i["address"]
                        address_data.append(
                            {
                                "id": l.get("id"),
                                "line": tuple([__i for __i in [l.get("line1").upper(), l.get("line2")] if __i]),
                                "city": l.get("city"),
                                "state": l.get("stateCode"),
                                "postalCode": l.get("zip", {}).get("code"),
                                "use": l.get(
                                    "use", "work"
                                ),  # added as part of the first feed back (the default value is 'work' )
                            }
                        )
                elif isinstance(self.data.get("locations").get("location"), dict):
                    x = []
                    x.append(self.data.get("locations").get("location"))
                    for _i in (x):
                        l = _i["address"]
                        address_data.append(
                            {
                                "id": l.get("id"),
                                "line": tuple([__i for __i in [l.get("line1").upper(), l.get("line2")] if __i]),
                                "city": l.get("city"),
                                "state": l.get("stateCode"),
                                "postalCode": l.get("zip", {}).get("code"),
                                "use": l.get(
                                    "use", "work"
                                ),  # added as part of the first feed back (the default value is 'work' )
                            }
                        )
            unique_address = {each['line']: each for each in address_data}.values()
            #print(unique_address)
            return unique_address

        except:
            return ""


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        print(AddressExtractors(_data).call_default)
