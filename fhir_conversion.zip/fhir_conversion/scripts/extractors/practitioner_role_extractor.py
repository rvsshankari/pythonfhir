from scripts.extractors.active_extractor import ActiveExtractors
from scripts.extractors.days_of_week_extractor import DaysOfWeekExtractors
from scripts.extractors.healthcare_service_extractor import HealthcareServiceExtractors
from scripts.extractors.location_extractor import LocationExtractors
from scripts.extractors.npi_extractor import NPIsExtractors
from scripts.extractors.organization_extractor import OrganizationExtractors
from scripts.extractors.speciality_extractor import SpecialityExtractors
import logging

class PractitionerRoleExtractors:
    """
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        locations/location/4/specialties/taxonomy
    """

    def __init__(self, pdata,businessName="Empty"):
        self.pdata = pdata
        self.businessName = businessName

    @property
    def call_default(self):
        __final_practitioner_data = []
        __final_practitioner_data.extend(self.practitioner_role_extractors())
        return __final_practitioner_data

    @staticmethod
    def extract_base(__data, __path):
        for i in __path.split("/"):
            __data = __data[i]
        return __data


    @property
    def call_default_business(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.business_id_extractor())
        return __final_identifier_data

    # def call_default_roster(self):
    #     __final_identifier_data = []
    #     __final_identifier_data.extend(self.roster_id_extractor())
    #     return __final_identifier_data

    @property
    def call_default_provider(self):
        __final_identifier_data = []
        __final_identifier_data.extend(self.provider_id_extractor())
        return __final_identifier_data

    def business_id_extractor(self, path=None):
        try:
            if isinstance(self.pdata.get("updateInfo"), str):
                #print(self.data.get("updateInfo"))
                return [self.pdata.get("businessId"), self.pdata.get("updateInfo"), self.pdata.get("businessName")]
            else:
                #print(self.data.get("businessId"), self.data.get("updateInfo").get("attestationDate"))
                return [self.pdata.get("businessId"), self.pdata.get("updateInfo").get("attestationDate"), self.pdata.get("businessName")]
        except Exception as e:
            print(e)
            return ""

    def provider_id_extractor(self, path=None):
        return [self.pdata.get("providerId"), self.pdata.get("updateInfo").get("attestationDate"), self.pdata]

    def practitioner_role_extractors(self, path=None):
        if type(self.pdata) is not None:
            keys_to_search = self.pdata.keys()
        practitioner_role_data = []
        try:
            if ("locations" in keys_to_search):
                if not path:
                    path = "locations/location"
                if isinstance(self.pdata.get("locations").get("location"), list):
                    period = {"period":{}}
                    for _i, _j in enumerate(self.extract_base(self.pdata, path)):
                        if ("typeCode" in _j):
                            practitioner_role_data.append({
                                "resources": {
                                "resourceType": "Practitioner Role",
                                "active": ActiveExtractors(self.pdata).call_default,
                                # "period":{},
                                "practitioner":
                                    {
                                        # "reference": "Practitioner/Practionerid",
                                        "type": "Practitioner",
                                        "identifier": {
                                            "system": "http://hl7.org/fhir/sid/us-npi",
                                            "value": ''.join(NPIsExtractors(self.pdata).call_default),
                                        }
                                    },
                                "organization":
                                    {
                                        # "reference": "Organization/businessname",
                                        "type": "Organization",
                                        "identifier":
                                            {
                                                "system": "http://hl7.org/fhir/sid/us-npi",
                                                "value": ''.join(NPIsExtractors(self.pdata).call_default),
                                            },
                                        "display": self.businessName,
                                    },
                                "speciality":
                                        [
                                            {
                                                "coding": [SpecialityExtractors(self.pdata).call_default],
                                            }
                                        ],
                                "availableTime": DaysOfWeekExtractors(self.pdata).call_default,
                                "telecom": [],
                                },
                                "request": {"method": "POST", "url": "PractitionerRole"}
                            })
                            if ("startDate" in _j):
                                if _j.get("startDate") is not None:
                                    period.get("period").update(
                                        {
                                            "startDate": _j.get("startDate")
                                        })
                            if ("endDate" in _j):
                                if _j.get("endDate") is not None:
                                    period.get("period").update(
                                        {
                                            "endDate": _j.get("endDate")
                                        })
                            if ("phone" in _j):
                                ph = _j.get("phone").get("areaCode") + _j.get("phone").get("phoneNumber")
                                loc = practitioner_role_data[_i].get("resources").get("telecom")
                                if type(loc) is list and len(loc) != 0:
                                    for i, j in enumerate(loc):
                                        ph_loc = loc[i].get("value")
                                        if (ph != ph_loc):
                                            practitioner_role_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "phone",
                                                    "value": ph,
                                                    "use": "work"
                                                }])
                                elif type(loc) is dict and len(loc) != 0:
                                    practitioner_role_data[_i].get("resources").get("telecom").extend(
                                        [{
                                            "system": "phone",
                                            "value": ph,
                                            "use": "work"
                                        }])
                                else:
                                    pass
                            if ("fax" in _j):
                                practitioner_role_data[_i].get("resources").get("telecom").extend(
                                    [{
                                        "system": "fax",
                                         "value": _j.get("fax").get("areaCode") + _j.get("fax").get("phoneNumber"),
                                         "use": "work"
                                    }])
                            if ("email" in _j):
                                practitioner_role_data[_i].get("resources").get("telecom").extend(
                                    [{
                                        "system": "email",
                                        "value": _j.get("email").lower(),
                                        "use": "work"
                                    }])
                            if ("alternatePhone" in _j):
                                if ("phone" in _j):
                                    ap = _j.get("alternatePhone").get("phoneNumber")
                                    p = _j.get("phone").get("phoneNumber")
                                    if (ap != p):
                                        practitioner_role_data[_i].get("resources").get("telecom").extend(
                                            [{
                                                "system": "alternatePhone",
                                                "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                    "alternatePhone").get("phoneNumber"),
                                                "use": "work"
                                            }])
                                    else:
                                        pass
                                else:
                                    practitioner_role_data[_i].get("resources").get("telecom").extend(
                                        [{
                                            "system": "alternatePhone",
                                            "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                "alternatePhone").get("phoneNumber"),
                                            "use": "work"
                                        }])
                            if (len(period["period"]) > 0):
                                practitioner_role_data[_i].get("resources").update(period)
                            l = _j.get("address").get("id")
                            if type(l) is not None:
                                practitioner_role_data[_i].get("resources").update({
                                    "location": [{
                                            "reference": l
                                        }]
                                    })
                            try:
                                hs = (HealthcareServiceExtractors(self.pdata).call_default)[_i].get("reference")
                                practitioner_role_data[_i].get("resources").update({
                                    "healthService":  [
                                            {
                                              "reference": hs
                                            }
                                        ]
                                })
                            except:
                                pass
                elif isinstance(self.pdata.get("locations").get("location"), dict):
                    x = []
                    x.append(self.pdata.get("locations").get("location"))
                    period = {"period":{}}
                    for _i, _j in enumerate(x):
                        if ("typeCode" in _j):
                            practitioner_role_data.append({
                                "resources": {
                                "resourceType": "Practitioner Role",
                                "active": ActiveExtractors(self.pdata).call_default,
                                "practitioner":
                                    {
                                        # "reference": "Practitioner/Practionerid",
                                        "type": "Practitioner",
                                        "identifier": {
                                            "system": "http://hl7.org/fhir/sid/us-npi",
                                            "value": ''.join(NPIsExtractors(self.pdata).call_default),
                                        }
                                    },
                                "organization":
                                    {
                                        # "reference": "Organization/businessname",
                                        "type": "Organization",
                                        "identifier":
                                            {
                                                "system": "http://hl7.org/fhir/sid/us-npi",
                                                "value": ''.join(NPIsExtractors(self.pdata).call_default),
                                            },
                                        "display": self.businessName,
                                    },
                                    "speciality":
                                        [
                                            {
                                                "coding": [SpecialityExtractors(self.pdata).call_default, ]
                                            }
                                        ],
                                    "availableTime": DaysOfWeekExtractors(self.pdata).call_default,
                                    "telecom": [],
                                },
                                "request": {"method": "POST", "url": "PractitionerRole"}
                            })
                            if ("startDate" in _j):
                                if _j.get("startDate") is not None:
                                    period.get("period").update(
                                        {
                                            "startDate": _j.get("startDate")
                                        })
                            if ("endDate" in _j):
                                if _j.get("endDate") is not None:
                                    period.get("period").update(
                                        {
                                            "endDate": _j.get("endDate")
                                        })
                            if ("phone" in _j):
                                ph = _j.get("phone").get("areaCode") + _j.get("phone").get("phoneNumber")
                                loc = practitioner_role_data[_i].get("resources").get("telecom")
                                if type(loc) is list and len(loc) != 0:
                                    for i, j in enumerate(loc):
                                        ph_loc = loc[i].get("value")
                                        if (ph != ph_loc):
                                            practitioner_role_data[_i].get("resources").get("telecom").extend(
                                                [{
                                                    "system": "phone",
                                                    "value": ph,
                                                    "use": "work"
                                                }])
                                else:
                                    practitioner_role_data[_i].get("resources").get("telecom").extend(
                                        [{
                                            "system": "phone",
                                            "value": ph,
                                            "use": "work"
                                        }])
                            if ("fax" in _j):
                                practitioner_role_data[_i].get("resources").get("telecom").extend(
                                    [{
                                        "system": "fax",
                                         "value": _j.get("fax").get("areaCode") + _j.get("fax").get("phoneNumber"),
                                         "use": "work"
                                    }])
                            if ("email" in _j):
                                practitioner_role_data[_i].get("resources").get("telecom").extend(
                                    [{
                                        "system": "email",
                                        "value": _j.get("email").lower(),
                                        "use": "work"
                                    }])
                            if ("alternatePhone" in _j):
                                if ("phone" in _j):
                                    ap = _j.get("alternatePhone").get("phoneNumber")
                                    p = _j.get("phone").get("phoneNumber")
                                    if (ap != p):
                                        practitioner_role_data[_i].get("resources").get("telecom").extend(
                                            [{
                                                "system": "alternatePhone",
                                                "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                    "alternatePhone").get("phoneNumber"),
                                                "use": "work"
                                            }])
                                    else:
                                        pass
                                else:
                                    practitioner_role_data[0].get("resources").get("telecom").extend(
                                        [{
                                            "system": "alternatePhone",
                                            "value": _j.get("alternatePhone").get("areaCode") + _j.get(
                                                "alternatePhone").get("phoneNumber"),
                                            "use": "work"
                                        }])
                            if (len(period["period"]) > 0):
                                practitioner_role_data[_i].get("resources").update(period)
                            l = _j.get("address").get("id")
                            if l is not None:
                                practitioner_role_data[_i].get("resources").update({
                                    "location": [{
                                        "reference": l
                                    }]
                                })
                            try:
                                hs = (HealthcareServiceExtractors(self.pdata).call_default)[0].get("reference")
                                practitioner_role_data[_i].get("resources").update({
                                    "healthService":  [
                                            {
                                              "reference": hs
                                            }
                                        ]
                                })
                            except:
                                pass
                else:
                    pass
                # print(practitioner_role_data)
                return practitioner_role_data
            else:
                return ""
        except Exception as e:
            print(e)
            logging.exception("message")
            return ""

if __name__ == "__main__":
    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER, BASE_TAGS_ROSTER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS)
    data_provider = json.loads(json_data)
    data_provider = remove_base_data_tags(data_provider, BASE_TAGS_PROVIDER)
    data_roster = json.loads(json_data)
    data_roster = remove_base_data_tags(data_roster, BASE_TAGS_ROSTER)
    for _data_ in data:
        businessId = PractitionerRoleExtractors(_data_).call_default_business[0]
        attestationDate = PractitionerRoleExtractors(_data_).call_default_business[1]
        businessName = PractitionerRoleExtractors(_data_).call_default_business[2]
        for rdata in data_roster:
            rbusinessId = rdata.get("businessId")
            rproviderId = rdata.get("providerId")
            if rbusinessId == businessId:
                for pdata in data_provider:
                    pproviderId = PractitionerRoleExtractors(pdata).call_default_provider[0]
                    pattestationDate = PractitionerRoleExtractors(pdata).call_default_provider[1]
                    pprovider = PractitionerRoleExtractors(pdata).call_default_provider[2]
                    if pproviderId == rproviderId and attestationDate == pattestationDate:
                        _data = pprovider
                        PractitionerRoleExtractors(pdata).call_default
