import json
import os

import pandas as pd
import xmltodict
from prettytable import PrettyTable
from scripts.extractors.configs import BASE_TAGS


def xml_to_json_converter(xml_file_name):
    """
    :description:
        this function takes a file name along with the complete path as input and returns the json format of that xml file.
    :xml_file_name:
        file name along with location
    :return:
        json
    :example:
        xml_to_json_converter("sample/sample.xml")
        > return the json of that file name sample.xml
    """

    with open(xml_file_name) as xml_file:
        data_dict = xmltodict.parse(xml_file.read())
    json_data = json.dumps(data_dict, indent=4)
    return json_data


def basic_cleanup(_data, tags):
    """
    :param _data:
        dict data the needs cleanup
    :return:
        dict with cleaned data
    """

    __data = remove_base_data_tags(_data, tags)
    return __data


def remove_base_data_tags(json_data, tags):
    """
    :param json_data:
        the json or dict object from which we need to remove the tags
    :param tags:
        the tags which should be removed from the dict/json
    :return:
        Any
    """

    _json_data = json_data.copy()
    for i in tags.split("/"):
        _json_data = _json_data[i]
    return _json_data


def open_file_jsonify(filename):
    """
    We are doing the basic clean up well
    Don't know just thought it makes sense to do it here
    :param filename:
        complete path to the file
    :return:
    """

    json_data = xml_to_json_converter(filename)
    data = json.loads(json_data)
    return remove_base_data_tags(data, BASE_TAGS)


def create_file(_file_name_with_path, _data):
    """
    we just create the file with the data we need to give the complete path
    :param _file_name_with_path:
        need to give the complete path to the file location to be created
    :param _data:
        any data type which is part of python can be passed as this is just a write
    :return:
        None
    """

    def get_folder_name_from_the_complete_path(__path):
        """
        We need to make sure that the filepath exists before pushing into the folder
        :param __path:
        :return:
        """
        return os.path.dirname(__path)

    os.makedirs(
        get_folder_name_from_the_complete_path(_file_name_with_path), exist_ok=True
    )

    with open(_file_name_with_path, "w") as f:
        _data = json.dumps(_data, indent=4)
        f.write(_data)


class CreatePrettyTable:
    def __init__(self, column_names):
        self.column_names = column_names

    def initialize(self):
        x = PrettyTable(self.column_names)
        x.align[self.column_names[0]] = "l"  # Left align file names
        x.padding_width = 1  # One space between column edges and contents (default)
        return x

    @staticmethod
    def write_file(_file_name, _data):
        with open(_file_name, "w") as w:
            w.write(str(_data))
        return True


def logger_time_taken_into_excel(_column_names, _data_frame, _file_name):
    """
    :param _column_names:
        it should be a list containing the column names of the table we are going to insert into the excel
    :param _data_frame:
        the data frame should be a list of list containing the length of the column names
    :param _file_name:
        the excel file name included with the extension
    """
    _df = pd.DataFrame(columns=_column_names, data=_data_frame)
    _df = _df.set_index(_column_names[0]).reset_index()
    _df.to_excel(_file_name, index=False)


def strip_empties_from_dict(data):
    """
    For the json validator to work we need to remove the empty things so using this one
    """
    def strip_empties_from_list(data):
        new_data = []
        for v in data:
            if isinstance(v, dict):
                v = strip_empties_from_dict(v)
            elif isinstance(v, list):
                v = strip_empties_from_list(v)
            if v not in (None, str(), list(), dict(),):
                new_data.append(v)
        return new_data
    new_data = {}
    for k, v in data.items():
        if isinstance(v, dict):
            v = strip_empties_from_dict(v)
        elif isinstance(v, list):
            v = strip_empties_from_list(v)
        if v not in (None, str(), list(), dict(),):
            new_data[k] = v
    return new_data
