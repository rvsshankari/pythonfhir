class QualificationExtractors:
    """
    Extracting the person or the practitioner Qualification
    :ref:
        https://www.hl7.org/fhir/practitionerrole-examples-general.json.html
        licenses
    """

    def __init__(self, data):
        self.data = data

    @property
    def call_default(self):
        return self.qualification_extractors()

    def qualification_extractors(self, path=None):
        """
        just assuming the tag may or may not present so just making True as the default value and returning the value
        if that tar present it should be in the hierarchy else it will be return the default value which is True
        :param path:
            optional path to remove | added this for future implimentation if needed
        :return:
            the licensing information in the fhir format if not just returning an empty dict
        """

        _li_data = self.data.get("licenses")

        if _li_data:
            __in_li_data = []
            if isinstance(_li_data.get("license"), dict):
                # just making sure multi licence vs single licence extraction will work as intended
                _li_data = {"license": [_li_data.get("license")]}
            for __li in _li_data.get("license"):
                if __li.get("originalIssueDate") and __li.get("expiredDate"):
                    __in_li_data.append(
                        {
                            "identifier": [
                                {
                                    "system": "http:availity/provider/quality",
                                    "value": ''.join(__li.get("number")),
                                },
                            ],
                            "code":
                                {
                                    "coding": [
                                        {
                                            "system": "http:availity/provider/quality",
                                            "code": __li.get("typeCode"),
                                            "display": __li.get("type"),
                                        },
                                    ],
                                    "text": __li.get("type"),
                                },
                            "period": {
                                "start": __li.get("originalIssueDate"),
                                "end": __li.get("expiredDate"),
                            },
                            "issuer": {
                                        "display": __li.get("issuingBody"),
                                        #"":__li.get("issuingStateCode")
                            },
                        }
                    )
                elif __li.get("originalIssueDate") is None:
                    __in_li_data.append(
                        {
                            "identifier": [
                                {
                                    "system": "http:availity/provider/quality",
                                    "value": ''.join(__li.get("number")),
                                },
                            ],
                            "code":
                                {
                                    "coding": [
                                        {
                                            "system": "http:availity/provider/quality",
                                            "code": __li.get("typeCode"),
                                            "display": __li.get("type"),
                                        },
                                    ],
                                    "text": __li.get("type"),
                                },
                            "period": {
                                #"start": __li.get("originalIssueDate"),
                                "end": __li.get("expiredDate"),
                            },
                            "issuer": {
                                "display": __li.get("issuingBody"),
                                # "":__li.get("issuingStateCode")
                            },
                        }
                    )
            return __in_li_data

        return {}


if __name__ == "__main__":

    import json
    from scripts.extractors.configs import BASE_TAGS, BASE_TAGS_PROVIDER
    from scripts.extractors.utils import xml_to_json_converter, remove_base_data_tags

    json_data = xml_to_json_converter("../../inputs/sample.xml")
    data = json.loads(json_data)
    data = remove_base_data_tags(data, BASE_TAGS_PROVIDER)
    for _data in data:
        # print(_data)
        print(QualificationExtractors(_data).call_default)
