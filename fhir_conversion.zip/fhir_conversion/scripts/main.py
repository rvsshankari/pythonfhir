import json
import pathlib
from time import perf_counter

from scripts import CreatePerson, CreatePractitioner
from scripts.create_bundle import CreateBundle
from scripts.create_location import CreateLocation
from scripts.create_organization import CreateOrganization
from scripts.extractors.utils import logger_time_taken_into_excel, strip_empties_from_dict, create_file

XML_FOLDER_LOCATION = "../inputs"  # input files location

PERSON_OUTPUT_FILE_LOCATION = "../outputs/practitioner"  # output folder location
PRACTITIONER_OUTPUT_FILE_LOCATION = "../outputs/practitioner_role"
ORGANIZATION_OUTPUT_FILE_LOCATION = "../outputs/organization"
LOCATION_OUTPUT_FILE_LOCATION = "../outputs/location"
BUNDLE_OUTPUT_FILE_LOCATION = "../outputs/bundle"


LOGGER_FILE_NAME = "../outputs/file.xlsx"

CREATE_PERSON = False
CREATE_PRACTITIONER = False
CREATE_ORGANIZATION = False
CREATE_LOCATION = False
CREATE_BUNDLE = True

COLUMN_NAMES = ["file Name", "Role file", "time Taken (sec)"]


def main():
    data_frame = []
    if pathlib.Path(XML_FOLDER_LOCATION).is_dir():
        for i in pathlib.Path(XML_FOLDER_LOCATION).rglob("*.xml"):
            try:
                if CREATE_PERSON:
                    st_1_time = perf_counter()
                    CreatePerson(
                        fr"{i.absolute()}",
                        output_file_location=PERSON_OUTPUT_FILE_LOCATION,
                    )
                    print(f"PRACTITIONER file execution is Done for file ----> {i}")
                    data_frame.append(
                        [i.name, "practitioner", f"{perf_counter() - st_1_time:.8f}"]
                    )
            except FileNotFoundError:
                print("File or folder is not accessible")
            try:
                if CREATE_PRACTITIONER:
                    st_1_time = perf_counter()
                    CreatePractitioner(
                        fr"{i.absolute()}",
                        output_file_location=PRACTITIONER_OUTPUT_FILE_LOCATION,
                    )
                    print(
                        f"PRACTITIONER ROLE file execution is Done for file ----> {i}"
                    )
                    data_frame.append(
                        [
                            i.name,
                            "practitioner role",
                            f"{perf_counter() - st_1_time:.8f}",
                        ]
                    )
            except FileNotFoundError:
                print("File or folder is not accessible")
            try:
                if CREATE_ORGANIZATION:
                    st_1_time = perf_counter()
                    CreateOrganization(
                        fr"{i.absolute()}",
                        output_file_location=ORGANIZATION_OUTPUT_FILE_LOCATION,
                    )
                    print(f"ORGANIZATION file execution is Done for file ----> {i}")
                    data_frame.append(
                        [i.name, "organization", f"{perf_counter() - st_1_time:.8f}"]
                    )
            except FileNotFoundError:
                print("File or folder is not accessible")
            try:
                if CREATE_LOCATION:
                    st_1_time = perf_counter()
                    CreateLocation(
                        fr"{i.absolute()}",
                        output_file_location=LOCATION_OUTPUT_FILE_LOCATION,
                    )
                    print(f"LOCATION file execution is Done for file ----> {i}")
                    data_frame.append(
                        [i.name, "location", f"{perf_counter() - st_1_time:.8f}"]
                    )
            except FileNotFoundError:
                print("File or folder is not accessible")
            try:
                if CREATE_BUNDLE:
                    st_time = perf_counter()
                    CreateBundle(
                        fr"{i.absolute()}",
                        output_file_location=BUNDLE_OUTPUT_FILE_LOCATION,
                    )
                    print(f"BUNDLE file execution is Done for file ----> {i}")
                    data_frame.append(
                        [i.name, "bundle", f"{perf_counter() - st_time:.8f}"]
                    )
            except FileNotFoundError:
                print("File or folder is not accessible")
    else:
        print("The folder doen't exist please check and update the new one")

    print("ALL is Done")



if __name__ == "__main__":
    main()
    for __path in [PERSON_OUTPUT_FILE_LOCATION, PRACTITIONER_OUTPUT_FILE_LOCATION, ORGANIZATION_OUTPUT_FILE_LOCATION, LOCATION_OUTPUT_FILE_LOCATION, BUNDLE_OUTPUT_FILE_LOCATION]:
        for _file in pathlib.Path(__path).rglob("*.json"):
            file = open(_file)
            _json_file = json.load(file)
            file.close()
            print(_file)
            create_file(_file, strip_empties_from_dict(_json_file))
